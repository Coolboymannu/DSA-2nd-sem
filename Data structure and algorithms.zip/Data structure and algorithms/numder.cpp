#include<iostream>
using namespace std;

int main(){
// int d1,d2, a = 12345;
// d1 = a%10;
// cout << d1 << endl;
// a = a/10;
// d2 = a%10;
// cout << d2;
int c,a = 123456;
while (true)
{
    c = a%10;
    a /=10;
    cout << c << endl;
    if (a == 0)
    {
        break;
    }
    
}

return 0;}